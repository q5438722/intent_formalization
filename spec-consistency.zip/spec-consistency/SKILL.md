---
name: spec-consistency
version: 0.4.0
description: >
  Research and development of LLM-based specification consistency evaluation for Verus.
  Covers the multi-agent pipeline for generating semantic queries (tests) against formal
  specifications, critic-based filtering, and entailment checking via Verus. Use when
  working on spec generation, spec completeness evaluation, consistency checking,
  test-based spec evaluation, or the intent formalization project.
---

# Spec Consistency — Entailment-Guided Specification Evaluation

## Project Goal

Evaluate the completeness/consistency of Verus specifications by systematically
querying the semantic space of the spec and checking for unintended entailments.

## Core Thesis

> A specification is consistent iff it entails all intended properties and none of the unintended ones.

See [references/theory.md](references/theory.md) for the full theoretical motivation.

## Architecture: 5-Step Modular Pipeline (v4)

```
Step 1: Extract        Parse AST → exec functions + declarations (strip_body)
       │
Step 2: Brainstorm     LLM generates natural-language negative properties
       │                 (spec-only + body-aware, with state_scenarios)
       │
Step 3: Formalize      LLM generates assume() bodies only → AST assembles proof fns
       │                 (requires/ensures mechanically extracted, never LLM-copied)
       │
Step 4: Entailment     Run Verus on each proof fn
       │                 verified → spec incomplete | failed → spec complete
       │
Step 5: Critic         Tautology check + LLM filtering → TP / FP verdicts
```

### Design Principles
- **Modular:** each step has `process_one()`, `run_task.py` calls them sequentially, `run_pipeline.py` adds parallelism
- **File-path-first:** LLM agents receive file paths, read source themselves
- **AST-based spec extraction:** requires/ensures come from the AST, not LLM copies (prevents spec-copy errors)
- **Shared utilities** in `pipeline_common.py`

## File Locations

```
~/intent_formalization/
├── src/
│   ├── pipeline/
│   │   ├── run_pipeline.py      # Parallel orchestrator (ProcessPoolExecutor)
│   │   ├── run_task.py          # Sequential: step1→2→3→4→5 for one task
│   │   ├── step1_extract.py     # AST extraction: exec fns + strip_body() declarations
│   │   ├── step2_brainstorm.py  # NL negative property generation (spec-only + body-aware)
│   │   ├── step3_formalize.py   # LLM body gen + assemble_proof_fn()
│   │   ├── step4_entailment.py  # Verus verification per φ
│   │   └── step5_critic.py      # Tautology check + LLM critic
│   └── utils/
│       ├── pipeline_common.py   # parse_phi_blocks(), parse_verdicts(), build_entailment_file()
│       ├── llm.py               # LLMClient (copilot CLI backend)
│       ├── verus.py             # run_verus() wrapper
│       ├── verus_parser.py      # tree-sitter Verus AST parser
│       └── spec_extract.py      # spec extraction utilities
├── verus.so                     # tree-sitter Verus grammar (shared object)
├── verus/verus                  # Verus binary (for verusage)
├── verusage/
│   ├── source-projects/         # VeruSage benchmark (~800 files)
│   └── workspace_v4/            # Per-file task dirs
├── nanvix/workspace/bitmap/     # Nanvix case study workspace
│   ├── original.rs              # Source under test
│   ├── exec_functions.json      # Step 1 output (with declarations)
│   ├── brainstorm_v2.json       # Step 2 output (15 properties with state_scenarios)
│   ├── candidates_v3.json       # Step 3 output (59 φ, AST-assembled)
│   ├── entailment_v3.json       # Step 4 results
│   ├── verdicts_v3.json         # Step 5 critic verdicts
│   └── verus_v3_stderr.txt      # Raw Verus output
├── scripts/
│   ├── run_pipeline_v3.py       # Standalone nanvix bitmap runner (all steps)
│   └── run_formalize_v2.py      # Legacy standalone formalize script
└── results/                     # VeruSage evaluation results
```

## Entailment Structure (assumes-in-body)

Each φ is a `proof fn` testing whether the spec can exclude a bad scenario:

```rust
proof fn phi_bad_scenario(pre: Bitmap, post: Bitmap, result: Result<usize, Error>)
    requires
        // EXACT from AST — mechanically extracted, never LLM-written
        pre.inv(),
    ensures
        // EXACT from AST — mechanically extracted, never LLM-written
        post.inv(),
        match result {
            Ok(index) => { ... },
            Err(_) => { ... },
        },
{
    // LLM-generated body ONLY: assume() statements encoding bad scenario
    // --- State assumptions ---
    assume(post.inv());
    assume(!pre@.is_full());
    // --- Bad scenario ---
    assume(result is Err);
}
```

**Interpretation:**
- **Verus verifies** → spec allows the bad behavior → **spec incomplete** (finding)
- **Verus fails** → spec excludes it → **spec complete** (no finding)

**Critical rules:**
1. `requires` / `ensures` = mechanically extracted from AST by `assemble_proof_fn()`. LLM never copies spec.
2. Body = only `assume()` statements. LLM generates body + PARAMS only.
3. Free variables: `pre` for `old(self)`, `post` for `self`, `result` for return value. May call spec fns / ghost methods.
4. `_rewrite_declaration_to_proof_fn()` handles: `old(self)→pre`, `self→post`, `*pre→pre` (deref removal), multi-line `old(\n self,\n)` via regex.

## AST-Based Spec Extraction (v3, 2026-03-30)

**Problem:** LLM spec copying caused false gaps — LLM dropped ensures clauses (alloc frame condition) or truncated Err branches (set liveness), making spec appear weaker than it is.

**Solution:** `step1_extract.py::strip_body()` uses tree-sitter AST to extract the full fn declaration with body replaced by `{ }`. `step3_formalize.py::assemble_proof_fn()` mechanically combines:
1. AST-extracted declaration → rewritten to `proof fn` with free variables
2. LLM-generated body (assume statements only)

**Result:** v2→v3 on nanvix bitmap: 3 gaps → 1 gap (2 were LLM spec-copy artifacts).

### Known Compile Issues with Assembly
- `*self` / `*old(self)` → proof fn params are values, not refs → strip `*` via regex
- `exists` quantifiers in LLM body may need manual `#![trigger ...]` annotations (`#![auto]` not always sufficient)
- Multi-line `old(\n  self,\n)` patterns require regex, not simple string replace
- Verus stops early with many errors; use `--multiple-errors` flag when available

## Evaluation Results

### Nanvix Bitmap (case study, multiple iterations)

| Version | Spec Source | φ | Verified | Critic TP | Critic FP | Real Gaps |
|---------|------------|---|----------|-----------|-----------|-----------|
| v2 (LLM copy) | LLM copies spec | 55 | 18 | 14 | 4 | 3 (but 2 were artifacts) |
| v3 (AST extract) | AST mechanical | 59 | 9 | 1 | 8 | **1** (new liveness) |

**v3 key finding:** Only 1 confirmed gap — `new()` missing liveness (valid input → Ok not guaranteed by spec). The v2 "alloc frame condition" and "set liveness" gaps were caused by LLM dropping ensures clauses.

### VeruSage Corpus (v3, 2026-03-25, 313 tasks)
- 1395 φ → 63 entailed (4.5%) → 36 critic TP → **4 confirmed TP after audit (11% precision)**
- All 4 from `CommitMask::next_run` (memory-allocator spec completeness gaps)
- Report: `~/intent_formalization/verusage/reports/workspace_v3_findings.md`

## Lessons Learned

### Ghost vs Exec: The #1 FP Source
67% of VeruSage FPs came from flagging ghost/spec-only data structures. Ghost invariants that admit more values than necessary are **strictly stronger**, not weaker. Critic must distinguish ghost vs exec code.

### Spec Copy Errors (eliminated by AST extraction)
In v2, LLM "exact copy" of spec was unreliable:
- Dropped `forall` frame condition clauses → false frame-condition gaps
- Truncated Err branches (`Err(_) => true` instead of actual condition) → false liveness gaps
- **AST extraction completely eliminates this class of errors**

### Tautological φ
Some φ verify regardless of spec (pure logic, platform facts). Tautology check (step 5a): strip spec, re-verify. If still passes → auto-FP.

### Deduplication Needed
Same gap flagged multiple times with different state scenarios. Critic catches duplicates but semantic dedup before entailment would save compute.

### Brainstorm Quality vs Entailment Filtering
LLM brainstorming precision ~33% without entailment. Entailment check is essential filter.

## Key Technical Details

### LLM Configuration
- Backend: GitHub Copilot CLI (`llm.py`)
- Default model: `claude-opus-4.6`
- `LLM_TIMEOUT=150` (default), `600` for formalize step
- `LLM_STALL_TIMEOUT=90` (kill if no stdout for 90s)
- `COPILOT_CWD=/tmp`

### Verus Environments
- **VeruSage:** `~/intent_formalization/verus/verus` binary, standalone .rs files
- **Nanvix:** `bash ~/nanvix/scripts/verify-bitmap.sh`, cargo-based, `set -e`

### Tree-sitter Parser
- Grammar: `~/intent_formalization/verus.so`
- Key methods: `verus_parser.extract_exec_functions()`, `extract_specifications()`, `extract_proofs()`
- `strip_body()`: `child_by_field_name('body')` → replace with `{ }`

### Two Spec Attribute Styles
1. `#[verus_spec(result => requires ... ensures ...)]` — nanvix style (attribute-based)
2. Inline `requires`/`ensures` in fn signature — verusage style
Both supported by `_rewrite_declaration_to_proof_fn()`

## Pipeline Coupling Points (Verus environment)

1. **Step 1:** needs tree-sitter Verus grammar (`verus.so`)
2. **Step 4:** needs Verus binary/build system to run verification
3. **Step 5a:** tautology check also needs Verus

### Proposed: VerificationBackend interface
Direction confirmed but not yet implemented. Would abstract over verusage (standalone) vs nanvix (cargo-based) verification environments.

## Open TODOs

- [ ] Implement VerificationBackend interface for verusage + nanvix
- [ ] Semantic deduplication before entailment (predicate-level)
- [ ] Run AST-based pipeline (v3) on more case studies beyond bitmap
- [ ] Critic precision improvement (currently 11% on VeruSage, 11% on nanvix v3)
- [ ] `run_task.py` early-return paths missing complete stats
- [ ] Handle inline-spec style more robustly in `_rewrite_declaration_to_proof_fn`

## Git History

| Tag | Commit | Description |
|-----|--------|-------------|
| v3.0 | `eb0f200` | Initial pipeline |
| v4.0 | `8d806df` | 5-step modular refactor |
| v4.1 | `fc141f6` | Step 3 prompt fix + nanvix findings |
| — | (latest) | AST-based spec extraction (step1 declarations + step3 assembly) |
