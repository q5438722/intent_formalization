# Theoretical Motivation — Consistency via Entailment-Guided Querying

## Background

Formal verification systems (e.g., Verus) let developers encode program intent as formal
specifications and mechanically prove correctness. A specification defines a semantic boundary:
it determines which inputs, behaviors, and logical consequences are admissible.

**Core problem:** User intent is inherently latent and cannot be directly observed or fully
specified. A spec may pass all proofs and tests yet still be *incomplete* — admitting unintended
behaviors or supporting invalid reasoning.

## Limitations of Existing Approaches

| Approach | What it checks | What it misses |
|----------|---------------|----------------|
| Executable testing | Concrete I/O behaviors | Semantic space beyond tested points |
| Formal verification | Implementation satisfies spec | Whether spec itself is correct |
| Mutation testing | Incorrect outputs rejected | Incorrect *reasoning* not rejected |

**Key insight:** Rejecting incorrect outputs does not imply rejecting incorrect reasoning.

## Consistency as Entailment Control

> A correct specification should entail all intended properties, and none of the unintended ones.

Reformulation: instead of asking "is S complete?", ask "does S incorrectly entail undesirable
properties?"

This shifts focus from **verification** to **entailment control**.

## Operationalization: Queries over the Semantic Space

Given spec S, construct query φ and check: S ⊢ φ

- If φ is undesirable but entailed → spec inconsistency
- **Behavioral queries**: φ encodes I/O relations (mutation testing = special case)
- **Boundary queries**: φ encodes input validity
- **Logical queries**: φ encodes arbitrary semantic claims

Traditional mutation testing generates queries in the behavioral space only. This framework
generalizes to the **entire semantic space**, enabling detection of **logical inconsistencies**
where the spec admits unintended reasoning even when all behaviors appear correct.

## Falsification-Oriented Evaluation

> Systematically generate undesirable properties and check whether the specification
> incorrectly entails them.

A specification is consistent if it rejects all queries outside the intended semantic space.

> **Specification completeness is not defined by what a specification can prove,
> but by what it refuses to entail.**

---

Source: ~/intent_formalization/consistency_v1.md
